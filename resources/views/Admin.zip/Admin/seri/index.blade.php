@extends('admin.layout')

@section('page-title', 'Data Seri')
@section('page-subtitle', 'Kelola seri BMW yang tersedia di sistem')

@section('content')

<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px,1fr)); gap:16px;">
    @foreach($seris as $s)
    <div class="card">
        <div class="card-header">
            <div style="display:flex; align-items:center; gap:10px;">
                <div style="width:36px; height:36px; border-radius:9px; background:#0f172a; color:#fff; font-family:'Space Grotesk',sans-serif; font-size:14px; font-weight:700; display:flex; align-items:center; justify-content:center;">{{ $s->id }}</div>
                <div>
                    <div style="font-family:'Space Grotesk',sans-serif; font-size:14px; font-weight:600;">{{ $s->nama }}</div>
                    <div style="font-size:11.5px; color:#64748b;">{{ $s->jumlah_model }} model tersedia</div>
                </div>
            </div>
            <button onclick="toggleSeri('seri-{{ $s->id }}')" class="btn btn-ghost btn-sm">Edit</button>
        </div>

        {{-- Preview --}}
        <div id="seri-{{ $s->id }}-preview" style="padding:12px 16px;">
            <p style="font-size:12.5px; color:#64748b; line-height:1.5;">{{ $s->deskripsi ?? 'Belum ada deskripsi.' }}</p>
            <div style="margin-top:10px; display:flex; gap:8px;">
                <a href="{{ route('admin.mobil', ['seri'=>$s->id]) }}" class="btn btn-ghost btn-sm">
                    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M5 17H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v9a2 2 0 0 1-2 2h-2"/>
                        <circle cx="7.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="17.5" r="2.5"/>
                    </svg>
                    Lihat {{ $s->jumlah_model }} Model
                </a>
            </div>
        </div>

        {{-- Edit form --}}
        <div id="seri-{{ $s->id }}" style="display:none; padding:16px; border-top:1px solid #f1f5f9;">
            <form method="POST" action="{{ route('admin.seri.update', $s->id) }}">
                @csrf @method('PUT')
                <div class="form-group">
                    <label class="form-label">Nama Seri</label>
                    <input type="text" name="nama" value="{{ $s->nama }}" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" rows="3">{{ $s->deskripsi }}</textarea>
                </div>
                <div style="display:flex; gap:8px;">
                    <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                    <button type="button" onclick="toggleSeri('seri-{{ $s->id }}')" class="btn btn-ghost btn-sm">Batal</button>
                </div>
            </form>
        </div>
    </div>
    @endforeach
</div>

<div style="margin-top:20px; padding:14px 18px; background:#fffbeb; border:1px solid #fde68a; border-radius:10px; font-size:13px; color:#92400e;">
    ⚠️ <strong>Perhatian:</strong> Slug seri tidak bisa diubah dari sini karena digunakan sebagai identifier di database dan URL. Hubungi developer jika perlu mengubah slug.
</div>

<script>
function toggleSeri(id) {
    const form = document.getElementById(id);
    const preview = document.getElementById(id + '-preview');
    const isHidden = form.style.display === 'none';
    form.style.display = isHidden ? 'block' : 'none';
    if (preview) preview.style.display = isHidden ? 'none' : 'block';
}
</script>

@endsection